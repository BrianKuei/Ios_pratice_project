//
//  ElectricCar.swift
//  Class
//
//  Created by student on 2019/3/14.
//  Copyright © 2019年 student. All rights reserved.
//

import Foundation

//繼承
class ElectricCar : Car{
    var source = "electric"
    
    override func printOut() {
        super.printOut()// super 可以保留父類別的使用
//        print("Power source is \(source)")
        
//        if destination != nil{
//            print("Destination is " + destination!) // ! 強制compiler執行
//        }
        
        //不用 ! 的方法
        if let userDefinedDest = destination{
            print("Destination is " + userDefinedDest)
        }
    }
    
    var destination : String?
    
}

