//
//  car.swift
//  Class
//
//  Created by student on 2019/3/14.
//  Copyright © 2019年 student. All rights reserved.
//

import Foundation

//enumeration
enum CarType{
    case Van
    case Sodan
    case SportCar
}

//類別
class Car{
    

    //attribute
    var color = "red"
    var numOfSeat = 5
    
    init(customeColor : String) {
        color = customeColor
    }
    
    //method
    func printOut(){
        print("This is a car")
    }
    
    var typeOfCar : CarType = CarType.SportCar //可以用簡寫  CarType = .SportCar
}
