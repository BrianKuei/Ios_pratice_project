//
//  SecondViewController.swift
//  Notepad
//
//  Created by student on 2019/3/21.
//  Copyright © 2019年 student. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

