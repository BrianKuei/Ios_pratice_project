//
//  ViewController.swift
//  LoginList
//
//  Created by Sunbu on 2019/5/7.
//  Copyright © 2019 Sunbu. All rights reserved.
//

import UIKit
import CoreData

class ViewController: UIViewController {
    
    var users : [Username] = []
    var isLoggedIn = false

    
    @IBOutlet weak var userInput: UITextField!
    @IBAction func saveData(_ sender: Any) {

        checkName(userID: userInput.text!)

        
        if isLoggedIn == true{
            performSegue(withIdentifier: "gotoSecondView", sender: self)
        }else{
            saveName()
        }
    }
    
    
    
    func saveName(){
        
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let myContext = appDelegate.persistentContainer.viewContext
        
        let users = Username(context: myContext)
        
        if userInput.text != nil {
            users.userID = userInput.text
        }
        
        do{
            try myContext.save()
            print("save successfully!")
        }catch{
            print("saveError")
        }

    }
    
    func checkName(userID: String){
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let myContext = appDelegate.persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<Username>(entityName: "Username")

        fetchRequest.predicate = NSPredicate(format: "userID == [c] %@", userID)

        do{
            users = try myContext.fetch(fetchRequest)

            if users.count > 0 {
                if users[0].userID != nil{
                    isLoggedIn = true
                }
            }
        }catch{
            print("data could not fetch")
        }

    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

