//
//  ViewController.swift
//  anime
//
//  Created by student on 2019/4/25.
//  Copyright © 2019年 student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var rectangle: UIView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        rectangle.center.y = rectangle.center.y - rectangle.frame.height
    }
    
    override func viewDidAppear(_ animated: Bool) {
        UIView.animate(withDuration: 2) {
            self.rectangle.center.y = self.rectangle.center.y + self.rectangle.frame.height
        }
    }


}























