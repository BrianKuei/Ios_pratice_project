//
//  ViewController.swift
//  rectangle animation
//
//  Created by student on 2019/4/25.
//  Copyright © 2019年 student. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let greenView = UIView()
        greenView.frame = CGRect(x: 0, y: 0, width: 100, height: 100)
        greenView.backgroundColor = UIColor(red: 0/255, green: 255/255, blue: 190/255, alpha: 1)
        
        view.addSubview(greenView)
        
        let redView = UIView()
        redView.frame = CGRect(x: 0, y: 0, width: view.frame.width * 1/3, height: 140)
        redView.backgroundColor = UIColor(red: 255/255, green: 0/255, blue: 0/255, alpha: 1)
        
        redView.center.x = view.frame.width * 1/2
        redView.center.y = view.frame.height * 3/4
        
        view.addSubview(redView)
        
        let  label = UILabel()
        
        label.frame = CGRect(x: 0, y: 0, width: redView.frame.width, height: redView.frame.height)
        label.text = "方 塊"
        label.textAlignment = .center
        label.textColor = UIColor.white
        
        redView.addSubview(label)
    }


}

